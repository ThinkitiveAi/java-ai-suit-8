package com.thinkitive.healthfirst.entity;

public enum AppointmentType {
    CONSULTATION,
    FOLLOW_UP,
    EMERGENCY,
    TELEMEDICINE
} 