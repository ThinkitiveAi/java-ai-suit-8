package com.thinkitive.healthfirst.entity;

public enum AvailabilityStatus {
    AVAILABLE,
    BOOKED,
    CANCELLED,
    BLOCKED,
    MAINTENANCE
} 