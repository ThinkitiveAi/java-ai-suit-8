package com.thinkitive.healthfirst.entity;

public enum RecurrencePattern {
    DAILY,
    WEEKLY,
    MONTHLY
} 