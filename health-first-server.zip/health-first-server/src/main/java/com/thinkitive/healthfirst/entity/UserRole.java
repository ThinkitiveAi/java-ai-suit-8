package com.thinkitive.healthfirst.entity;

public enum UserRole {
    PROVIDER,
    PATIENT
} 