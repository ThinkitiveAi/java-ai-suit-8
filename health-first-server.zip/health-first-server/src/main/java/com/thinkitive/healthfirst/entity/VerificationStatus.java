package com.thinkitive.healthfirst.entity;

public enum VerificationStatus {
    PENDING,
    VERIFIED,
    REJECTED
} 